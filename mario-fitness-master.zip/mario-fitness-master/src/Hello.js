const Hello = (props) => {

    return (<div className='container text-center'>
        <h1>Hello React... 😉</h1>
        <p>by susuSoft</p>
        <button className='btn btn-danger'>hmmm</button>
        <p>{props.udv}</p>
    </div>)

}

export default Hello

/* class Hello extends Component {
    render() {
        return (<div className='container text-center'>
            <h1>Hello React... 😉</h1>
            <p>by susuSoft</p>
            <button className='btn btn-danger'>hmmm</button>
            <p>{this.props.udv}</p>
        </div>)
    }
} */